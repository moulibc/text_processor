# text_processor/__init__.py

from .summarizer import TextSummarizer

__all__ = ["TextSummarizer"]